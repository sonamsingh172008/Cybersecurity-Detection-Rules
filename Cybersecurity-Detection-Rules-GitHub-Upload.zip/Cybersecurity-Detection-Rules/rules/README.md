# Detection rule configuration notes

This folder is intended to hold exported rule definitions or carefully documented configuration details for the three custom rules.

## Rules in scope

- Windows Credential Stuffing Detection
- Sysmon DNS Query Monitoring
- PowerShell Script Block Monitoring

## Required details for each rule

When recording a rule, include:

- Exact saved rule name
- Rule type
- Query language and complete query
- Index patterns / data view
- Required event fields and event IDs
- Threshold / grouping settings, if applicable
- Schedule and look-back interval
- Severity and risk score
- Enabled status
- Test event and observed alert result

**Important:** The screenshots currently available show rule names, enabled status, latest response, and execution logs. They do not expose the complete rule queries or all configuration settings. Add those details from Kibana's **Edit rule settings** page or from an exported rule definition; do not guess them.
