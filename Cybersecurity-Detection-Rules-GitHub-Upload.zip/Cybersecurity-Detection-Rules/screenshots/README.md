# Screenshot evidence

Save the four original Kibana screenshots in this folder:

1. `credential-stuffing.png`
2. `sysmon-dns.png`
3. `powershell-monitoring.png`
4. `detection-rules-overview.png`

Use the original, unedited screenshots where possible. Make sure the rule names, enabled states, and execution statuses remain readable. Before committing, check that no credentials, tokens, private hostnames, personal data, or sensitive log content are exposed.

The screenshots were reviewed in the ChatGPT conversation, but the original image files have not yet been added to this repository.
