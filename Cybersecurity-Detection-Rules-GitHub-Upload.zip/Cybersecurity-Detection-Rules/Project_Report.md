# Project Report: Custom SIEM Detection Rules Using Elastic Security and Sysmon

## 1. Project summary

This project documents the configuration and monitoring of three custom detection rules in Elastic Security (Kibana):

- Windows Credential Stuffing Detection
- Sysmon DNS Query Monitoring
- PowerShell Script Block Monitoring

The purpose is to demonstrate how endpoint and authentication-related telemetry can be monitored through SIEM detection rules and how rule execution can be reviewed in Kibana.

## 2. Objectives

- Configure custom detection rules in Elastic Security.
- Monitor authentication-related activity and selected Windows telemetry.
- Review scheduled rule executions and alert counts.
- Preserve screenshots as evidence of rule status and execution results.
- Document observations and identify further validation work.

## 3. Tools and technologies

| Tool / technology | Role |
|---|---|
| Elastic Security | SIEM detection-rule management and execution monitoring |
| Kibana | Interface for configuring rules and reviewing execution results |
| Sysmon | Windows endpoint telemetry source for DNS and PowerShell-related events |

The screenshots establish use of Elastic Security / Kibana. The exact Sysmon version, Elastic version, operating-system build, data streams, and deployment topology were not visible in the supplied evidence and should be filled in from the actual lab environment.

## 4. Detection rules

### 4.1 Windows Credential Stuffing Detection

**Purpose:** Identify authentication patterns that may be consistent with credential stuffing, where repeated login attempts use multiple username/password combinations.

**Evidence observed:** The rule details page displays the name **Windows Credential Stuffing Detection**, the rule is enabled, and its latest response is **Succeeded**. The latest visible execution row is a successful scheduled run with 0 alerts created.

**Configuration to document from Kibana:** Add the actual query, source index/data view, threshold or cardinality settings (if any), schedule, look-back interval, and required authentication fields. These settings cannot be determined from the execution-results screenshot alone.

### 4.2 Sysmon DNS Query Monitoring

**Purpose:** Monitor DNS-query events recorded by Sysmon. DNS telemetry can support investigation of unusual domain lookups and potentially suspicious name-resolution activity.

**Evidence observed:** The rule details page displays **Sysmon DNS Query Monitoring**, the rule is enabled, and its latest response is **Succeeded**. The latest visible execution row is a successful scheduled run with **4 alerts created**.

**Configuration to document from Kibana:** Add the actual query, Sysmon event ID and fields used, source index/data view, schedule, and look-back interval. Do not assume these values without checking the saved rule settings.

### 4.3 PowerShell Script Block Monitoring

**Purpose:** Monitor PowerShell script-block telemetry to support investigation of potentially suspicious PowerShell activity.

**Evidence observed:** The rule details page displays **PowerShell Script Block Monitoring**, the rule is enabled, and its latest response is **Succeeded**. The latest visible execution row is a successful scheduled run with 0 alerts created.

**Configuration to document from Kibana:** Add the actual query, event provider / event ID and fields used, source index/data view, schedule, and look-back interval from the saved rule settings.

## 5. Testing and evidence review

The supplied Kibana screenshots show the following:

| Detection rule | Enabled | Latest visible response | Alerts in latest visible row |
|---|---:|---|---:|
| Windows Credential Stuffing Detection | Yes | Succeeded | 0 |
| Sysmon DNS Query Monitoring | Yes | Succeeded | 4 |
| PowerShell Script Block Monitoring | Yes | Succeeded | 0 |

The overview screenshot lists these three custom rules and shows their enabled toggles and successful last responses.

### Historical execution note

The execution-results screenshots also contain older rows marked **Failed**. The latest visible rows are marked **Succeeded**. The historical failures should not be hidden; investigate their messages and document any corrective action if the project requires a full execution-history analysis.

### What the current evidence proves

- The three named rules are present in Elastic Security.
- All three are enabled in the overview.
- Their latest visible responses are successful.
- The latest visible Sysmon DNS execution created four alerts.

### What still needs validation

A successful execution status means the rule ran successfully; it does not independently prove that the detection logic catches every intended attack pattern. For a stronger test report, run controlled, authorized test cases and record:
- the test event generated;
- the expected rule and alert;
- the actual alert result;
- the event timestamp and execution timestamp;
- any false positives or missed detections.

## 6. Screenshots

Place the original screenshots in the repository's `screenshots/` folder:

1. `credential-stuffing.png` — Windows Credential Stuffing Detection execution results.
2. `sysmon-dns.png` — Sysmon DNS Query Monitoring execution results.
3. `powershell-monitoring.png` — PowerShell Script Block Monitoring execution results.
4. `detection-rules-overview.png` — overview showing the three rules and enabled statuses.

The screenshots were supplied in the ChatGPT conversation and visually reviewed. The original image files have not yet been committed to this repository.

## 7. Conclusion

The screenshots provide evidence that the three custom Elastic Security detection rules were enabled and that their latest visible executions completed successfully. The Sysmon DNS Query Monitoring rule generated four alerts in the latest visible execution, while the latest visible executions for the credential-stuffing and PowerShell rules generated zero alerts.

Further controlled testing and documentation of the exact saved rule queries and schedules are recommended before presenting this as a complete validation of detection effectiveness.

## 8. Author's completion checklist

- [ ] Add the four original screenshots to `screenshots/`.
- [ ] Record Elastic and Sysmon versions and lab environment details.
- [ ] Export or transcribe the exact saved rule queries and settings.
- [ ] Investigate historical failed execution entries.
- [ ] Run controlled authorized test cases and record expected vs. actual alerts.
- [ ] Review the repository for secrets and sensitive log data before making it public.
