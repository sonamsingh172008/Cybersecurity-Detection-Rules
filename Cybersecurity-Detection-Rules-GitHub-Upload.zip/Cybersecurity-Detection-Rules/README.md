# Cybersecurity Detection Rules

Custom SIEM detection rules built and tested in Elastic Security (Kibana), with Windows telemetry from Sysmon.

## Project overview

This project documents three custom detection rules:

1. **Windows Credential Stuffing Detection** — intended to identify suspicious authentication activity consistent with credential-stuffing behavior.
2. **Sysmon DNS Query Monitoring** — monitors DNS-query telemetry collected from Sysmon.
3. **PowerShell Script Block Monitoring** — monitors PowerShell script-block telemetry.

The exact KQL/EQL queries, index patterns, thresholds, and rule schedules should be added from the actual Kibana rule settings. They are not inferred in this repository.

## Evidence observed in Kibana

Screenshots reviewed during project documentation show:

- Each of the three named rules is enabled.
- Each rule's latest response is shown as **Succeeded**.
- The execution-results pages show successful scheduled executions.
- The Sysmon DNS Query Monitoring page shows 4 alerts created in the latest visible execution.
- The Windows Credential Stuffing Detection and PowerShell Script Block Monitoring pages show 0 alerts in their latest visible executions.
- Older failed execution entries are also visible in the logs; the report distinguishes those historical failures from the latest successful responses.

## Repository structure

- `Project_Report.md` — project report and test observations.
- `rules/README.md` — rule-configuration documentation checklist.
- `screenshots/README.md` — instructions for adding the original Kibana evidence screenshots.

## Screenshots

Add the four original screenshots to `screenshots/` using these filenames:

- `credential-stuffing.png`
- `sysmon-dns.png`
- `powershell-monitoring.png`
- `detection-rules-overview.png`

The screenshots were reviewed in the ChatGPT conversation, but the image files themselves have not yet been uploaded to this GitHub repository. Please add the original image files so they remain available as repository evidence.

## Reproduction and validation

1. Configure Sysmon to collect the Windows events required by the rules.
2. Confirm the relevant event data is arriving in the Elastic data view / indices.
3. Configure each custom detection rule in Elastic Security.
4. Enable the rules and allow scheduled executions.
5. Review **Security → Rules → Detection rules (SIEM) → Execution results**.
6. Record the rule name, latest response, execution timestamp, alerts created, and any historical failures.

## Safety and scope

Run detection tests only on systems and accounts you own or are explicitly authorized to monitor. Do not commit credentials, API keys, personal data, or sensitive production logs.

## Status

The three rules' latest visible responses were **Succeeded** in the screenshots reviewed. This is evidence of successful rule execution, not by itself proof that every possible attack scenario was detected correctly. Detection efficacy should be validated with controlled, authorized test events and documented expected results.
